package com.example.demo.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.*;

@Entity
@Table(name="Hotel")
public class Hotel {
	
	@Id  //it will be serve as primary key 
	@GeneratedValue(strategy=GenerationType.IDENTITY)// use for genrate unique
	private Long id;
	
	@NotBlank(message="Name Required")
	private String name;
	private String hoteltype;
	private String quality;
	
	
	
	//non parameterized construction
	public Hotel() {
		
		
	}
	
	// paramertized construction

	public Hotel(String name, String hoteltype, String quality, Long id) {
		super();
		this.name = name;
		this.hoteltype = hoteltype;
		this.quality = quality;
		this.id = id;
	}

	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHoteltype() {
		return hoteltype;
	}
	public void setHoteltype(String hoteltype) {
		this.hoteltype = hoteltype;
	}
	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
	@Override
	public String toString() {
		return "Hotel [name=" + name + ", hoteltype=" + hoteltype + ", quality=" + quality + ", id=" + id + "]";
	}
	
	

}
